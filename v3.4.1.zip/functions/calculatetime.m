function [timeinterval] = calculatetime(distance,desiredcruisespeed)
timeinterval=[0 distance/desiredcruisespeed];
end

